    <h1>Coast City Computers</h1>
    <strong>Buy Online or Call 1-800-555-1212</strong>
    <hr>
