Exercise 01_06_01
